<h1 style="text-align: center;">DAVSY Content Marketing Platform</h1>
<img src="<?php echo base_url('assets/images/Coming-Soon-PNG.png');?>" alt="Davsy coming soon">