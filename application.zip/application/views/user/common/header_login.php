<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>TOOL</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <link href="https://outreachdeal.com/wp-content/uploads/2018/09/fav.png" rel="shortcut icon">
    <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('assets/css/toastr.min.css');?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('assets/css/icons.css');?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('assets/css/main.css');?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('assets/css/style.css');?>" rel="stylesheet" type="text/css">
</head>
<div id="preloader" style="display:none">
    <div id="status">
        <div class="spinner">
            <img src="https://app.davsy.com:443/assets/images/loader.gif" class="hw-100" alt="">
        </div>
    </div>
</div>
