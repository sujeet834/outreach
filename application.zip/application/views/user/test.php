
<!-- end page title end breadcrumb -->
<style type="text/css">
    .select2-container .select2-selection--single {
    box-sizing: border-box;
    cursor: pointer;
    display: block;
    height: 35px;
    user-select: none;
    -webkit-user-select: none;
}
td{
        padding-left: 20px;

</style>

<label>INSTRUCTIONS</label></br>
<label>1. For DA, Cost Price and Traffic Range search like da from 30 to 50 then put 30,50@ </label></br>
<label>2. For single Niche search like Health then put Health@ </label></br>
<label>3. For searching without community and agency type no in the web category  </label></br>
<label>4. For Niche search in every website like Health then put Health*  </label></br>

<table class="table table-striped" id="">
    <thead>
        <tr>
           
            <th scope="col">Language</th>
            <th scope="col">Total Sites</th>
        </tr>
    </thead>
    <tbody>
        <?php if(!empty($languagewise)){ foreach($languagewise as $values){ ?>
        <tr>
      		<td><?php echo $values['language']; ?></td>
            <td><?php echo $values['ltotal']; ?></td>
        </tr>
        <?php } } ?>
    <tbody>
</table>

<table class="table table-striped language_table exmtbl" id="language_table">
    <thead>
        <tr>
           
            <th scope="col">Website</th>
            <th scope="col">Niche</th>
            <th scope="col">DA</th>
            <th scope="col">Email</th>
            <th scope="col">Language</th>
            <th scope="col">Price</th>
            <th scope="col">Currency</th>
            <th scope="col">From ID</th>
             <th scope="col">Ahref Traffic</th>
             <th scope="col">Semrush Tr.</th>
            <th scope="col">Date</th>
        </tr>
    </thead>
    <tbody>
        <tr>
      		<td>www.alvinology.com</td><td>Good</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>50</td>
            <td>45</td>
            <td>25</td>
             <td>522</td>
            <td>500</td>
            <td>650</td>
            
            
        </tr>
        <tr>
      		<td>www.alvinology.com</td><td>Good</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>50</td>
            <td>45</td>
            <td>25</td>
             <td>522</td>
            <td>500</td>
            <td>650</td>
            
            
        </tr>
        <tr>
      		<td>www.alvinology.com</td><td>Good</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>50</td>
            <td>45</td>
            <td>25</td>
             <td>522</td>
            <td>500</td>
            <td>650</td>
            
            
        </tr>
        <tr>
      		<td>www.alvinology.com</td><td>Good</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>50</td>
            <td>45</td>
            <td>25</td>
             <td>522</td>
            <td>500</td>
            <td>650</td>
            
        </tr>
        <tr>
      		<td>www.alvinology.com</td><td>Good</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>50</td>
            <td>45</td>
            <td>25</td>
             <td>522</td>
            <td>500</td>
            <td>650</td>
            
        </tr>
        <tr>
      		<td>www.alvinology.com</td><td>Good</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>50</td>
            <td>45</td>
            <td>25</td>
             <td>522</td>
            <td>500</td>
            <td>650</td>
            
        </tr>
        <tr>
      		<td>www.alvinology.com</td><td>Good</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>50</td>
            <td>45</td>
            <td>25</td>
             <td>522</td>
            <td>500</td>
            <td>650</td>
            
        </tr>
        <tr>
      		<td>www.alvinology.com</td><td>Good</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>50</td>
            <td>45</td>
            <td>25</td>
             <td>522</td>
            <td>500</td>
            <td>650</td>
            
        </tr>
        <tr>
      		<td>www.alvinology.com</td><td>Good</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>50</td>
            <td>45</td>
            <td>25</td>
             <td>522</td>
            <td>500</td>
            <td>650</td>
            
        </tr>
        <tr>
      		<td>www.alvinology.com</td><td>Good</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>Travel,Entertainment,Lifestyle,Food</td>
            <td>50</td>
            <td>45</td>
            <td>25</td>
             <td>522</td>
            <td>500</td>
            <td>650</td>
            
        </tr>
    </tbody>
</table>

